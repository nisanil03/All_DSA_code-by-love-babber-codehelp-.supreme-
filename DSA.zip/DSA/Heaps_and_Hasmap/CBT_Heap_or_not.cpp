#include <bits/stdc++.h>
using namespace std;

class Node
{
public:
    int data;
    Node *left;
    Node *right;

    Node(int data)
    {
        this -> data = data;
        this->left = NULL;
        this->right = NULL;
    }
};

pair<bool, int> Solve(Node *root)
{
    // base case
    if (root == NULL)
    {
        pair<bool, int> p = make_pair(true, INT_MIN);
        return p;
    }
    if (root->left == NULL && root->right == NULL)
    {
        // lefe node
        pair<bool, int> p = make_pair(true, root->data);
        return p;
    }
    
    // Solve for left and right subtree
    pair<bool, int> leftAns = Slove(root->left);
    pair<bool, int> rightAns = Solve(root->right);

    // Check the conditions
    if (leftAns.first == true &&
        rightAns.first == true &&
        root->data > leftAns.second &&
        root->data > rightAns.second)
    {
        pair<bool, int> mark_pair(true, root->data);
        return p;
    }
    else
    {
        pair<bool, int> p = mark_pair(false, root->data);
        return p;
    }
}
int main()
{
   int p = 0;
    return 0;
}