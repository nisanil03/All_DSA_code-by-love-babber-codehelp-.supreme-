#include <bits/stdc++.h>
using namespace std;
int main()
{
    // max-heap
    priority_queue<int> pq;
    pq.push(3);
    pq.push(6);
    pq.push(9);
    pq.push(4);
    pq.push(8);

    cout << "Top element :" << pq.top() << endl;
    pq.pop();

    cout << "Top element :" << pq.top() << endl;
    pq.pop();

    cout << "Top element :" << pq.top() << endl;
    pq.pop();

    cout << "Top element :" << pq.top() << endl;
    pq.pop();

    cout << "Top element :" << pq.top() << endl;
    pq.pop();

    cout << "Size :" << pq.size() << endl;

    if (pq.empty())
    {
        cout << "Max heap is emptiy" << endl;
    }

    else
    {
        cout << "Max heap is not a empty" << endl;
    }

    // Creation of min heap
    priority_queue<int, vector<int>, greater<int>> p;
    // Insertion
    p.push(23);
    p.push(12);
    p.push(67);
    p.push(15);
    // Top element
    cout << p.top() << endl;
    // Deleting the top element
    p.pop();
    // Size of priority queue
    cout << p.size() << endl;
    // Check empty or not
    if (p.empty())
    {
        cout << "empty " << endl;
    }
    else
    {
        cout << "not empty" << endl;
    }

    return 0;
}