#include <iostream>
#include <unordered_map>
using namespace std;

int main()
{

    // creation
    unordered_map<string, int> m;

    // insertion
    pair<string, int> p = make_pair("hello", 9);
    m.insert(p);

    pair<string, int> p2("Anil", 2);
    m.insert(p2);

    m["fortuner"] = 10;

    // access
    cout << m.at("hello") << endl;
    cout << m.at("Anil") << endl;
    cout << m.at("fortuner") << endl;

    // search
    cout << m.count("hello") << endl;

    // find
    if (m.find("fortuner") != m.end())
    {
        cout << "Fortuner found " << endl;
    }
    else
    {
        cout << "Fortuner not found " << endl;
    }

    // print size
    cout<<m.size()<< endl;
    //size of insetion  
    cout<<m["hummer"]<< endl;

    cout<<m.size()<< endl;

    // itereate the map
    cout<<"printing all enteries : "<< endl;

    for(auto i : m)
    {
        cout<<i.first << "-> " <<i.second << endl;
    }

    return 0;
}