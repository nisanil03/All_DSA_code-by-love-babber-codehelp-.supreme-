#include<iostream>
#include<unordered_map>
using namespace std;

bool CheckCircular(Node* head){
    unordered_map<node* , bool> vis;
    node * temp = head;

    while(temp != NULL){
        if(vis.find(temp) != vis.end()){
            vis[temp] = true;
        }
        else{
            return false;
        }
        temp = temp ->next;
    }
    return false;
}
int main(){

    
    return 0;
}