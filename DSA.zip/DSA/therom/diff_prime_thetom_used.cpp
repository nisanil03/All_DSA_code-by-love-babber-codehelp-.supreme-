#include <bits/stdc++.h>
using namespace std;

vector<bool> Sieve(int n)
{
    // create a sieve array of N size telling isPrime

    vector<bool> sieve(n + 1, true);
    sieve[0] = sieve[1] = false;

    for (int i = 2; i * i <= n; i++) // optimize2:sieve
    {
        if (sieve[i] == true)
        {
            // int j = i * 2;
            int j = i * i; //(optional 1:
                           // first unmarked number wolid be i*i , as others have been marked by 2 to (i-1).
            while (j <= n)
            {
                sieve[j] = false;
                j += i;
            }
        }
    }
    return sieve;
}

vector<bool> segsieve(int L, int R)
{
    // get me prime array, i will use it to mark seg sieve.
    vector<bool> sieve = Sieve(sqrt(R));
    vector<int> basePrime;
    for (int i = 0; i < sieve.size(); i++)
    {
        if (sieve[i])
        {
            basePrime.push_back(i);
        }
    }
    vector<bool> segsieve(R - L + 1, true);
    if (L == 1 || L == 0)
    {
        segsieve[0] = false;
    }
    for (auto prime : basePrime)
    {
        int first_multiple = (L / prime) * prime;
        if (first_multiple < L)
        {
            first_multiple += prime;
        }
        int j = max(first_multiple, prime * prime);
        while (j <= R)
        {
            segsieve[j - L] =false;
            j += prime;
        }
    }
    return segsieve;
}

int main()
{

    /*vector<bool> sieve = Sieve(25);
    for (int i = 0; i <= 25; i++)
    {
        if (sieve[i])
        {
            cout << i << " ";
        }
    }*/

    int L = 110;
    int R = 130;
    vector<bool> ss = segsieve(L, R);
    for (int i = 0; i < ss.size(); i++)
    {
        if (ss[i])
        {
            cout << i + L << " ";
        }
    }

    return 0;
}