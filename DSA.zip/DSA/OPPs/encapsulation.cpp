#inclue < bits / stdc++.h>
using namespace std;

class Animal
{
private:
    int age;
    int weight;

public:
    void eat()
    {
        cout << "eating";
    }
    int getAge()
    {
        return this -> Age;
    }
    void setAge(int age)
    {
        this -> age = age;
    }
};

int main()
{

    return 0;
}
