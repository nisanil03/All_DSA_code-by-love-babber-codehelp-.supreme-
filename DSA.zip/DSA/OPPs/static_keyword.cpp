#include <bits/stdc++.h>
using namespace std;
class abc
{
public:
    int x, y;
    abc() : x(0), y(0) {}
    static void print()
    {
        // this pointer
        ptintf("I AM STATIC PTINT %S \n",__FUNCTION_);
    }
};

int main()
{
    abc obj1;
    abc::print();

    abc obj2;
    abc::print();
    abc::print();

    return 0;
}
