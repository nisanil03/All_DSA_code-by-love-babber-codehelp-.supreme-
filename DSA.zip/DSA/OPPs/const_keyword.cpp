#include <bits/stdc++.h>
using namespace std;
/*class abc
{
    int x;
    int *y;

public:
    abc()
    {
        x = 0;
        y = new int(0); // default value of integer is zero, so we are
    }
    abc(int _x, int _y)
    {
        x = _x;
        *y = _y;
    }
    int getx() const
    {
        return x;
    }
    void setx(int _val)
    {
        x = _val;
    }

    int gety() const
    {
        // int f = 20;
        // y = &f;
        return *y;
    }
    void sety(int _val)
    {
        *y = _val;
    }
};*/

class abc{
  int x;
  int *y;
  int z;
  public:

// initialization list
abc(int _x , int _y, int _z = 0):x(_x),y(new int (_y)),z(_Z)(){}
};






void printABC(const abc &a)
{
    cout << a.getx() << " " << a.gety() << endl;
}
int main()
{
    abc a(1, 2);
    printABC(a);
    // cout << a.getx() << endl;
    // cout << a.gety() << endl;
    return 0;
}
int main2()
{

    // TYPE 1. const variable understanding

    // const int x = 5;//x is constant
    // initiization can be done.
    // but we cant ree-assingn a value.
    // x = 10;
    // int *p = &x;//purane complier mai run hota tha ye.
    //*p = 10; // constant variable change kasai kare
    // cout<<x<<endl;

    // Type  2.A. const with pointers

    /*const int *a = new int(2);//CONST data or NON-CONST pointer.
    int const *a = new int (2);//same se line no.17.
    *a = 3;// cant change the constant of pointer
    cout << *a << endl;
    delete a;
    int b = 5;
    a = &b;//pointer itself can be reassigned.
    cout << *a << endl;*/

    // Type 2.B.CONST pointer ,but NON-CONSTdata.

    /*int *const a = new int(2);
    cout << *a << endl;
    *a = 20; // chal jayega ye
    cout << *a << endl;
    int b = 50;
    a = &b//ye nahi chalega q ki pointer constant hai */

    // Type 2.C.CONSTANT DATA OR CONSTANT POINTER

    /*const int*const a = new int(10);
    cout<<*a<<endl;
    *a = 50;
    int b = 100;
    a = &b;//not assinged the data because error*/

    return 0;
}