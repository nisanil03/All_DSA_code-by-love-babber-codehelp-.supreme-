#include <bits/stdc++.h>
using namespace std;

#define PI 3.14159465
#define MAX(x, y) (x > y ? x : y)

float circleArea(float r)
{
    return PI * r * r;
}
float circlePerimeter(float r)
{
    return 2 * PI * r;
}
void fun()
{
    int x = 6;
    int b = 17;
    int c = MAX(x, b);
}
void fun2()
{
    int a = 6;
    int b = 17;
    int c = MAX(a, b);
}
void fun3()
{
    int x = 6;
    int y = 17;
    int c = MAX(x, y);
}
int main()
{
    cout << circleArea(65.3) << endl;
    cout << circlePerimeter(65.3) << endl;
    return 0;
}