#include <bits/stdc++.h>
using namespace std;
class A
{
public:
    int chemistry = 7;
};
class B
{
public:
    int chemister = 3;
};
class C : public A, public B
{
public:
    int maths = 4;
};
int main()
{
    C obj;
    cout << obj.A::chemistry << endl; // scope resolution fix
    cout << obj.B::chemister << endl; // scope resolution fix
    cout << obj.maths << endl;

    return 0;
}