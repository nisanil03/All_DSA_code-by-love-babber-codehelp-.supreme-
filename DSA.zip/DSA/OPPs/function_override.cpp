#include <bits/stdc++.h>
using namespace std;

class Animal
{
public:
  void speak()
  {
    cout << "speaking" << endl;
  }
};


class Dog : public Animal
{
public:
  // override
  void speak()
  {
    cout << "barking" << endl;
  }
};


int main()
{
  // Animal a;
  // a.speak();

  // 1 -> case

  // Animal * a = new Animal();
  // a -> speak();

  // 2-> case

  // Dog * a = new Dog();
  // a -> speak();

  // 3 -> case

  // UPCasting
  // Animal * a = new Animal();
  // a -> speak();

  // 4 -> case


  // DownCasting
   Dog* b = (Dog*)new Animal();//explict type casting karna padega 
   b  -> speak();


  return 0;
}
