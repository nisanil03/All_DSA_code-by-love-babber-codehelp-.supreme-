#include <bits/stdc++.h>
using namespace std;

/*inline void  numberShow(int num)
{
    cout << num << endl;
}*/
int main()
{

    
    numberShow(10);//cout << 10 << endl; ye inline pr replace hoto hai 
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);
    numberShow(10);

    return 0;
}