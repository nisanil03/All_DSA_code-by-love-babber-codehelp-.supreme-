#include <bits/stdc++.h>
using namespace std;

class Animal
{
public:
    Animal()
    {
        cout << "I am inside Animal constructor called" << endl;
    }
    virtual void speak()
    {
        cout << "Speaking" << endl;
    }
};
class Dog : public Animal
{
public:
    Dog()
    {
        cout << "I am inside Dog constructor called" << endl;
    }
    virtual void speak()
    {
        cout << "Speaking" << endl;
    }
};
int main()
{
    // case 1-> o/p calling Animal constructor
   // Animal* a = new Animal();

    // case 2 -> calling animal or dog constructor(inhertance behaviour)
   // Animal * a = new Dog();

    //case 3 -> calling animal or dog constructor(inhertance behaviour)
    //Dog* a = new Dog();
    
    // case 4 ->  calling are both constructor
    //Animal * a = (Animal *) new Dog();
     
     //case 5 ->calling are only Animal constructor
     Dog* b = (Dog*) new Animal();



    return 0;
}