#include<bits/stdc++.h>
using namespace std;
class car{
    public:
    string name;
    int age;
    int weight;

    void speedUp(){
        cout<<"The car is going faster"<<endl;
    } 
    void breckmaro(){
        cout<<"Breckmaroing the car"<<endl;
    }
};
class Scorpio : public car{


};
int main(){
    
      Scorpio nishawali;
      nishawali.speedUp();

    return 0;
}