#include<bits/stdc++.h>
using namespace std;
class Animal {
// preant class/base class
 protected:
 int age;


};
class Dog : protected Animal{
            public:
            void print(){
                cout<< this -> age;
            }

};
int main(){
Dog d1;
d1.print();

    return 0;
}