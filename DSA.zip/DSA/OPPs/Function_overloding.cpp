#include <bits/stdc++.h>
using namespace std;
class maths
{
public:
    int sum(int a, int b)
    {
        cout << "I am first Signature " << endl;
        return a + b;
    }
    int sum(int a, int b, int c)
    {
        cout << "I am second Signature " << endl;
        return a + b + c;
    }
    int sum(int a, float b)
    {
        cout << "I am thired Signature " << endl;
        return a + b + 10;
    }
};
int main()
{
    maths obj;

    cout << obj.sum(2, 5.12f) << endl;

    return 0;
}