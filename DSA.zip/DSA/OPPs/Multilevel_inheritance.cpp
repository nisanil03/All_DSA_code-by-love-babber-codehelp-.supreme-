#include <bits/stdc++.h>
using namespace std;
class Fruit
{
public:
    string name = "mango";
};

class mango : public Fruit
{
public:
    int weight;
};

class Alphanso : public mango
{
public:
    int sugurLevel;
};

int main()
{
    Alphanso a;
    cout << a.name << " " << a.weight << " " << a.sugurLevel << endl;
    return 0;
}