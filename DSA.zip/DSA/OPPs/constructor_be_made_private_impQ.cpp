#include <bits/stdc++.h>
using namespace std;
class Box
{
    int width;
    // ctor
    Box(int _w) : width(_w){}; // ctor(constructor)

public:
    int getWidth() const
    {
        return width;
    }
    void setWidth(int _val)
    {
        width = _val;
    }
    friend class BoxFactory;
};
class BoxFactory
{
    int count;

public:
    Box getBox(int _w)
    {
        ++count;
        return Box(_w);
    }
};
int main()
{
    // Box b(5);
    // cout << b.getWidth() << endl;
    // Box a;
    BoxFactory bfact;
    Box b = bfact.getBox(5);
    cout << b.getWidth() << endl;

    return 0;
}