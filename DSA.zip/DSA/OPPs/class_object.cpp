#include <bits/stdc++.h>
using namespace std;
class Animal
{
  private:
   int weight;


    public:    //acceses modifieary
   //state of properties 
    int age;
    string name ;
   
    // behaviour( function / class )
    void eat()
    {
      cout<<"Eating"<<endl;

    }
    void sleep()
    {
     cout<<"sleeping"<<endl;

    }int getweight(){
      return weight;
    }

    void setweight(int weight){
      this-> weight = weight;
    }
};

int main()
{
    
      // object creatation
     
    

      // static memory allocation 
      /*Animal ramesh;

      ramesh.age = 33;
      ramesh.name = "lion";
      ramesh.weight = 33;

     cout<<" age of ramesh is : "<<ramesh.age<<endl;
     cout<<" name of ramesh is : "<<ramesh.name<<endl;
     cout<<" weight of ramesh is : "<<ramesh.weight<<endl;
      
      
      ramesh.eat();
      ramesh.sleep();
      ramesh.getweight();*/

      //dynamic memory allocation;
      Animal *suresh = new Animal;
      /*
      (*suresh).age = 13;
      (*suresh).type = "bille"; 
      */


      // alternative approch
       suresh->age = 17;
       suresh->name = "kuyya";
       suresh->eat();

    return 0;
}





