#if !defined(BIRD_H)
#define BIRD_H
#include <bits/stdc++.h>
class Bird
{
public:
    virtual void eat() = 0;
    virtual void fly() = 0;
    // classes that inherits this class
    //  has to implement pure virtual fun.
};

class Sparrow : public Bird
{
public:
    void eat()
    {
        std::cout << "Sparrow is eating \n";
    }
    void fly()
    {
        std::cout << "Sparrow is eating \n";
    }
};

class egle : public Bird
{
public:
    void eat()
    {
        std::cout << "Egle is eating \n";
    }
    void fly()
    {
        std::cout << "Egle is eating \n";
    }
};
class piggon : public Bird
{
public:
    void eat()
    {
        std::cout << "piggon is eating \n";
    }
    void fly()
    {
        std::cout << "piggonis eating \n";
    }
};


#endif // BIRD_H