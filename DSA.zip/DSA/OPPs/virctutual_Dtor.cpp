#include <bits/stdc++.h>
using namespace std;

class base
{
public:
    base()
    {
        cout << "Base ctor \n";
    }
     virtual ~base()
    {
        cout << "Base dtor\n";
    }
};
class Drived : public base
{
    int *a;

public:
    Drived()
    {
        a = new int(1000);
        cout << "Drives ctor \n";
    }
    ~Drived()
    {
        delete[] a;
        cout << "Dtor\n";
    }
};

int main()
{
    base *b = new Drived();
    delete b;
    return 0;
}