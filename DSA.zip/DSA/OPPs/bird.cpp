#include <bits/stdc++.h>
#include "bir.h"
using namespace std;

void birddoesomething(Bird *bird)
{
    bird->fly();
    bird->eat();
    bird->fly();
    bird->fly();
    bird->eat();
    bird->fly();
    bird->fly();
    bird->eat();
    bird->fly();
    bird->fly();
    bird->eat();
    bird->fly();
    bird->fly();
    bird->eat();
    bird->fly();
}

int main()
{
    Bird*bir = new piggon();
    birddoesomething(bir);
    return 0;
}

