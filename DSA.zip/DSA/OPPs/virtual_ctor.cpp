#include <bits/stdc++.h>
using namespace std;

virtual class base
{
public:
     virtul base()
    {
        cout << "Base ctor \n";
    }
};
class Drived : public base
{
public:
    Drived()
    {
        cout << "Drives ctor \n";
    }
    ~Drived()
    {
        cout << "Dtor\n";
    }
};

int main()
{
    base *b = new Drived();
    delete b;
    return 0;
}