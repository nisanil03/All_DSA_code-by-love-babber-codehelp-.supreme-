#include <bits/stdc++.h>
using namespace std;
class parameter
{
public:
    int val;

    void operator+(parameter obj2)
    {
        int value1 = this->val;
        int value2 = obj2.val;
        cout << (value2 - value1) << endl;
    }
};

int main()
{
    parameter obj1, obj2;
    obj1.val = 7;
    obj2.val = 2;
    // this should print the difference between them
    obj1 + obj2;

    return 0;
}