#include<bits/stdc++.h>
using namespace std;
class Car{
    public:
    int age;
    int weight;
    string name;

    void Speedup(){
        cout<<"Speed is fast"<<endl;
    }
};

class Scropio : public Car{


};
class Fortuner: public Car{
 
};
int main(){
Scropio s1;
s1.Speedup();

Fortuner s2;
s2.Speedup();


    return 0;
}