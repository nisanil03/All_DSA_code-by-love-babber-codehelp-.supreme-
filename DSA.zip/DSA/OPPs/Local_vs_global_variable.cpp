#include <bits/stdc++.h>
using namespace std;

int x = 2; // GLOBAL VARIABLE
void fun()
{
    int x = 6;
    ::x = 60;
    cout << x << endl;
}

int main()
{
    x = 4;               // Acceses of globle variable
    int x = 20;          // local to main function
    cout << ::x << endl; // accessing the globle with using scope revolusion
    cout << x << endl;
    {
        int x = 50;
        cout << x << endl;
        cout << ::x << endl;
    }
    fun();
    return 0;
}