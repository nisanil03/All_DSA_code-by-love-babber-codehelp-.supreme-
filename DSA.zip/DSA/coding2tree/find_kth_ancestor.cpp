#include <bits/stdc++.h>
using namespace std;
class Node
{
public:
    int data;
    Node *left;
    Node *right;
    // create the construte
    Node(int data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
};
// create the function
Node *buildTree(int data)
{
    // 1-data indicates that we have arrived at the leaf node & hence return NULL.
    // depands on the question
    if (data == -1)
    {
        return NULL;
    }
    // create root node(solve one case )
    Node *root = new Node(data);

    // recussion handle for left & right subtree
    int leftData;

    cout << "Enter data of left of" << data << endl;
    cin >> leftData;
    root->left = buildTree(leftData);

    int rightData;
    cout << "Enter data right of " << data << endl;
    cin >> rightData;
    root->right = buildTree(rightData);

    return root;
}

bool kthAncestor(Node *root, int &k, int p)
{
    // base case
    if (root == NULL)
    {
        return false;// p not found
    }

    if (root->data == p)
    {
        return true; // p found
    }
    // if(k == 0){
    //     return false;
    // }
    
    // Find in left subtree
    bool leftAns = kthAncestor(root->left,k, p);

    // Find in right subtree
    bool rightAns = kthAncestor(root->right,k, p);

// wapas aa rehe honge 
// check left ya right me answer mile ya anhi
    if (leftAns || rightAns)
    {
        k--;
    }
    if (k == 0)
    {
        cout << "Answer : "<<root->data <<endl;
        k = -1;
    }
    return leftAns || rightAns;
}
int main()
{
    Node *root;
    int data;
    cout << "Enter data for root node" << endl;
    cin >> data;
    root = buildTree(data);

    int k = 1;
    int p = 4;
    bool found =kthAncestor(root, k, p);

    return 0;
}