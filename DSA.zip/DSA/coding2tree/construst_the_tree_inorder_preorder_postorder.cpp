#include <bits/stdc++.h>
using namespace std;
class Node
{
public:
    int data;
    Node *left;
    Node *right;

    Node(int data)
    {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};

int findPossition(int arr[], int n, int element)
{
    for (int i = 0; i < n; i++)
    {
        if (arr[i] == element)
        {
            return i;
        }
    }
    return -1;
}

// bild tree from inorder and preorder traversal
Node *buildTreefromPreOrder(int inorder[], int preorder[], int size, int &preindex, int inorderstart, int inorderend)
{
    // base case
    if (preindex >= size || inorderstart > inorderend)
    {
        return NULL;
    }

    // step A;
    int element = preorder[preindex++];
    Node *root = new Node(element);
    int pos = findPossition(inorder, size, element);

    // step b : rrot ->left solve
    root->left = buildTreefromPreOrder(inorder, preorder, size, preindex, inorderstart, pos - 1);

    // step c root -> right solve
    root->right = buildTreefromPreOrder(inorder, preorder, size, preindex, pos + 1, inorderend);

    return root;
}
void levelOrderTraversal(Node *root)
{
    // Empty tree
    if (root == NULL)
    {
        return;
    }
    queue<Node *> q;
    // Push the root in queue
    q.push(root);
    q.push(NULL);
    // Run the loop until queue becomes empty
    while (!q.empty())
    {
        // Fetch front node and then pop
        Node *temp = q.front();
        q.pop();
        if (temp == NULL)
        {
            // go to the next line
            cout << endl;
            // Marking for next level
            if (!q.empty())
            {
                q.push(NULL);
            }
        }
        else
        {
            cout << temp->data << " ";
            // left child exists
            if (temp->left)
            {
                q.push(temp->left);
            }
            // right child exists
            if (temp->right)
            {
                q.push(temp->right);
            }
        }
    }
}
int main()
{
    int inorder[] = {40, 20, 50, 10, 60, 30, 70};
    int preorder[] = {10, 20, 40, 50, 30, 60, 70};
    int size = 7;
    int preindex = 0;
    int inorderstart = 0;
    int inorderend = size - 1;

    cout << "Building Tree :" << endl;
    Node *root = buildTreefromPreOrder(inorder, preorder, size, preindex, inorderstart, inorderend);

    cout << endl
         << " printing lavel order traversal" << endl;
    levelOrderTraversal(root);
    return 0;
}