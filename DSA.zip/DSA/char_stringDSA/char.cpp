#include<bits/stdc++.h>
using namespace std;
int main(){
    //char name[100];
    //cout<<"Enter your name "<<endl;
    //cin>>name;
    //cout<<"App ka naam "<< name <<" "<<"hai"<<endl;
    //char ch[100];
    //ch[0] = 'a';
    //ch[1] = 'b';
    //cin >> ch[2];
    //cout<<ch[0]<<" "<<ch[1]<<" "<<ch[2]<<" "<<endl;

   // char name[100];
   // cout<<"Enter your name :"<<endl;
   // cin>>name;
   //for(int i= 0; i<7; i++){
   //     cout<<"index"<< " "<<i<<" "<<"value :"<<name[i]<<endl;
    //}
    //int value =(int)name[6];
    //cout<<"value is :"<<value<<endl;

    char name[100];
    cout<<"Enter your name"<<endl;
    //getline(cin,name);
    cin.getline(name,50);
    cout<<"your full_name is :"<<name<<endl;





    return 0;
}