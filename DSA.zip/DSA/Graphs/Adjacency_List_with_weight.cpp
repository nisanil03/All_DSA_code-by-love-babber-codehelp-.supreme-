#include <bits/stdc++.h>
using namespace std;
template <typename T>

class Graph
{
public:
    unordered_map<T, list<T>> adjList;

    void addEdge(T u, T v, bool direction)
    {
        // direction = 0 -> undirected graph
        // direction = 1 -> directed graph
        // create an pdge from u to v
        adjList[u].push_back(v);

        if (direction == 0)
        {
            // undirection edge
            // create an edge from v to u

            adjList[v].push_back(u);
        }
    }
    void printAdjancencyList()
    {
        for (auto node : adjList)
        {
            cout << node.first << "->";
            for (auto neighbour : node.second)
            {
                cout <<neighbour<<",";
            }
            cout << endl;
        }
    }
};
int main()
{

    
    // Graph<char> g;
    // g.addEdge('a', 'b', 0);
    // g.addEdge('b', 'c', 0);
    // g.addEdge('a', 'c', 0);
    // g.printAdjancencyList();

    // Graph g;
    //  direction input
    //  //g.addEdge (srcNode , destNode , weight , direction);
    //  g.addEdge(0, 1, 5, 1);
    //  g.addEdge(1, 2, 8, 1);
    //  g.addEdge(0, 2, 6,1);
    //  cout<<endl;
    //  g.printAdjancencyList();

    // undirected edge input
    // g.addEdge(0, 1, 0);
    // g.addEdge(1, 2, 0);
    // g.addEdge(0, 2, 0);

    // cout << endl;
    // g.printAdjancencyList();

    return 0;
}