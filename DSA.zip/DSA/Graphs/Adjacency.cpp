#include<bits/stdc++.h>
using namespace std;

class G
int main(){


    return 0;
}