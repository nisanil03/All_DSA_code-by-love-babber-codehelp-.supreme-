#include <bits/stdc++.h>
using namespace std;
int solve(int **ptr)
{
  // output //case 1 value of x is same  
    ptr = ptr + 1;

   // output //case 2 value of x is same but value of q is updated
    *ptr = *ptr + 1;

    // output //case 3 value of x is change 
    **ptr = **ptr + 1;
}

int main()
{
    int x = 12;
    int *p = &x;
    int **q = &p;

    solve (q);

    cout << x << endl;

    return 0;
}