#include <bits/stdc++.h>
using namespace std;
int main()
{

    //int arr[4] = {12,44,66, 18};

    //cout << arr << endl;
    //cout << arr[0] << endl;
    //cout << &arr << endl;
    //cout << &arr[0] << endl;
   
    //int *p = arr;
    //cout<<p<<endl;
    //cout<<p[0]<<endl;
    //cout<<&p<<endl;
    //cout<<&p[0]<<endl;

    //cout<< *arr<<endl;
    //cout<<arr[0]<<endl;
   // cout<< *arr+1<<endl;
   // cout<< *(arr)+1<<endl;
   //cout<< *(arr + 1)<<endl;
   // cout<<arr[1]<<endl;
    //cout<< *(arr + 2)<<endl;
    //cout<<arr[2]<<endl;
    //cout<< *(arr + 3)<<endl;
    //cout<< arr[3]<<endl;
    
    //int i = 0;
    //cout<<arr[i]<<endl;
    //cout<<i[arr]<<endl;
   // cout<<*(arr + i)<<endl;
   //cout<<*(i + arr)<<endl;

    //arr=arr + 2;

    //int * p = arr;
    //p = p + 1;

    //int arr[10];
    //cout<< sizeof(arr)<<endl;

    //int *p = arr;
    //cout<<sizeof(p)<<endl;
      
    //char ch[10]= "nisha";
    //char*c = ch;

    //cout<<ch<<endl;
    //cout<<&ch<<endl;
    //cout<<ch[0]<<endl;

    ///cout<<&c<<endl;
    //cout<<*c<<endl;
   
   //cout<<c<<endl;
    
    //char name[9] = "sherBano";
    //char* c = &name[0];

    //cout<<name<<endl;
    //cout<<&name<<endl;
    //cout<<*(name +3)<<endl;
    //cout<<c<<endl;
    //cout<<&c<<endl;
    //cout<<*(c + 3)<<endl;
    //cout<< c+2 <<endl;
    //cout<< *c<<endl;
    //cout<< c+8 <<endl;

   

   /*int func(int arr[5]){
    cout<<arr<<endl;
    cout<<*arr<<endl;
    cout<<&arr<<endl;
    cout<<sizeof(arr)<<endl;
   }

  int func2(int *arr){
    cout<<arr<<endl;
    cout<<*arr<<endl;
    cout<<&arr<<endl;
    cout<<sizeof(arr)<<endl;
  }

  int main(){
    int arr[5] ={10,20};
    cout<<arr<<endl;
    cout<<*arr<<endl;
    cout<<&arr<<endl;
    cout<<sizeof(arr)<<endl;

    func(arr);
    func2(arr);

    return 0;

  }*/
  
  int a = 7;
  int* ptr = &a;
  update(ptr);

  void  update(int* p){
    *p =*p+10;
  }





    return 0;
}


