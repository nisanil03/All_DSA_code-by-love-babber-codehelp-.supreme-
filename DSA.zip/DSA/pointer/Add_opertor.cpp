#include <bits/stdc++.h>
using namespace std;
int main()
{

    // int a = 5;
    // int b = 5;

    // cout<<a<<endl;
    // cout<<b<<endl;

    // cout<<&a<<endl;
    // cout<<&b<<endl;

    // int a = 5;
    //  create a pointer
    // int *ptr = &a;
    //  access the value of ptr is pointing to
    // cout << *ptr << endl;

    // cout << "address of a is:" << &a << endl;
    // cout << "Value stored at ptr is:" << ptr << endl;
    // cout << "value ptr is pointing to is " << *ptr << endl;
    // cout<<&ptr<<endl;

    // int a = 5;
    // int *p = &a;

    // cout << sizeof(p) << endl;

    // char ch = 'n';
    // char *c = &ch;

    // cout << sizeof(c) << endl;

    // double dtr = 5.03;
    // double *d = &dtr;

    // cout << sizeof(d) << endl;

    // BAD PRACTICE CODE
    // int *ptr;
    // cout<<*ptr<<endl;

    // int*ptr = nullptr;
    // cout<<*ptr<<endl;

    // int a = 5;
    // int*p = &a;

    // int a = 5;

    // int *ptr = &a;

    // copy pointers
    // int* dusraptr = ptr;

    // cout<<*ptr<<endl;
    // cout<< *dusraptr<<endl;

    int a = 10;
    int *p = &a;
    int *q = p;
    int *r = q;

    cout << a << endl;//10
    cout << &a << endl;//addreas of a
    cout << p << endl;//addreas of a
    cout << &p << endl;//addreas of p
    cout << *p << endl;//10
    cout << q << endl;//addreas of a
    cout << &p << endl;//addreas of q
    cout << *q << endl;//10
    cout << r << endl;//addreas of a
    cout << &r << endl;//addreas of r
    cout << *r << endl;//10
    cout << (*p + *q + *r) << endl;//30
    cout << (*p)*2 + (*r)*3 << endl;//50
    cout << (*p/2)-(*q)/2 << endl;//0
    

    return 0;
}