#include <bits/stdc++.h>
using namespace std;
// pass by value by pointer variable answer are different

/*void solve(int *p)
{
    p = p + 1;
}*/

// pass by reference by pointer variable answer are different
void solve(int*& p)
{
    p = p + 1;
}



// pass by reference by reference variable answer are different

/*void solve(int &nums)
{
    nums++;
   // nums = 50;
}*/

// pass by value by reference variable answer are same
/*void solve(int value)
{

    value++;
}*/

// void solve(int* val){
//  *val=*val+1;
//}

int main()
{

    /*int a = 5;
    solve(a);

    cout << a << endl;

    return 0;*/
    /*
    int a = 12;
     solve(&a);

     cout<<a << endl;
    */
    int a = 5;
    int *p = &a;

    solve(p);

    cout << "Before" << p << endl;
    solve(p);
    cout << "After" << p << endl;
}