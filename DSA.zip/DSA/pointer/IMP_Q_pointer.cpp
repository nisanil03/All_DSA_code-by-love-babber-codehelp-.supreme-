#include<bits/stdc++.h>
using namespace std;
int* solve(){
    int a = 5;
    int* p =&a;
    return &a;
}
int main(){
    int* ptr = solve();
    cout<<ptr<<endl;
    return 0;
}