#include <bits/stdc++.h>
class Solution
{
public:
    int ladderLength(string beginWord, string endWord, vector<string> &wordList)
    {
        queue<pair<string, int>> q;
        q.push({beginWord, 1});
        unordered_set<string> st(wordList.begin(), wordList.end());
        // jo bhi word queue me insert karunga , toh uska set me se remove krdunga
        st.erase(beginWord);

        while (!q.empty())
        {
            pair<string, int> frontNode = q.front();
            q.pop();

            string currString = frontNode.first;
            int currCount = frontNode.second;

            // check kahin destination tak toh nahi pocha gaye
            if (currString == endWord)
                return currCount;

            for (int index = 0; index < currString.length(); index++)
            {
                // Hr index pr jo value h , usko main 'a' to 'z' se replace karunga
                char originalCharacter = currString[index];
                for (char ch = 'a'; ch <= 'z'; ch++)
                {
                    currString[index] = ch;
                    // check in WordList;
                    if (st.find(currString) != st.end())
                    {
                        q.push({currString, currCount + 1});
                        st.erase(currString);
                    }
                }
                // bringing back the currString to its original state
                currString[index] = originalCharacter;
            }
        }
        return 0;
    }
};