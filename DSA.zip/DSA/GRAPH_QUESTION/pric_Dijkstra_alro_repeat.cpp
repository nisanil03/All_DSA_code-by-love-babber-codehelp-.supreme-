#include<bits/stdc++.h>
using namespace std;
int main(){
     graph g;
     g.addEdge(0, 1, 5 , 1);

     return 0;
}
