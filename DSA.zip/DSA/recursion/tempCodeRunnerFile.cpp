;
    int target = 99;
    int s = 0;